using System;
using Expedia;
using NUnit.Framework;

namespace ExpediaTest
{
	[TestFixture()]
	public class FlightTest
	{
		//DONE Task 7 items go here
        private readonly DateTime startDate = new DateTime(2010, 1, 18);
        private readonly DateTime endDate = new DateTime(2010, 1, 23);
        private readonly int miles = 1000;

        [Test()]
        public void TestThatFlightInitializes()
        {
            var target = new Flight(startDate, endDate, miles);
            Assert.IsNotNull(target);
        }

        [Test()]
        public void TestThatFlightHasCorrectBasePriceForOneDayLength()
        {
            var target = new Flight(new DateTime(2010, 1, 18), new DateTime(2010, 1, 19), 10);
            Assert.AreEqual(220, target.getBasePrice());
        }
        [Test()]
        public void TestThatFlightHasCorrectBasePriceForTwoDayLength()
        {
            var target = new Flight(new DateTime(2010, 1, 18), new DateTime(2010, 1, 20), 10);
            Assert.AreEqual(240, target.getBasePrice());
        }
        [Test()]
        public void TestThatFlightHasCorrectBasePriceForTenDayLength()
        {
            var target = new Flight(new DateTime(2010, 1, 18), new DateTime(2010, 1, 28), 10);
            Assert.AreEqual(400, target.getBasePrice());
        }
        [Test()]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void TestThatFlightMilesThrowsOnBadNumber()
        {
            new Flight(new DateTime(2010, 1, 18), new DateTime(2010, 1, 28), -4);
        }

        [Test()]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestThatFlightDatesThrowsOnBadDate()
        {
            new Flight(new DateTime(2010, 1, 20), new DateTime(2010, 1, 18), 20);
        }

        [Test()]
        public void TestThatFlightMilesIsCorrect()
        {

            var target = new Flight(new DateTime(2010, 1, 18), new DateTime(2010, 1, 28), 10);
            Assert.AreEqual(10, target.Miles);
        }
	}
}
